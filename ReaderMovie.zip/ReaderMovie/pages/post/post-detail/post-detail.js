var postsData = require("../../../data/post-data.js");

Page({

  data:{

  },

  onLoad:function(option){
    // 从上个界面跳转的时候传递的 id
    var postId = option.id;
    this.data.currentPostId = postId;
    var postItemData = postsData.postList[postId];
    // 如果在 onload 方法中，不是异步的去执行一个数据绑定，则
    // 不需要 使用 this.setData 方法，只需要对 this.setData 赋值即可实现数据绑定
    // this.data.postData 中的 postData 相当于 在 data 中创建了个变量
    // this.data.postData = postItemData;
    this.setData({
      postData: postItemData
    })

    var postsCollected = wx.getStorageSync("posts_collected")

    if (postsCollected){
      var postCollected = postsCollected[postId];
      this.setData({
        collected: postCollected
      })
    }else{
      var postsCollected = {};
      postsCollected[postId] = false;
      wx.setStorageSync("posts_collected", postsCollected)
    }

  },


  onColletionTap: function () {
    // 同步
    // this.getPostsCollectedSyc();
    // 异步
    this.getPostsCollectedAsy();

  },

  getPostsCollectedSyc:function(){

  },

  getPostsCollectedAsy: function () {
    var that = this;
    wx.getStorage({
      key: 'posts_collected',
      success: function(res) {
        var postsCollected = res.data;
        var postCollected = postsCollected[that.data.currentPostId]
        // 收藏变成未收藏，未收藏变成收藏
        postCollected = !postCollected;
        postsCollected[that.data.currentPostId] = postCollected;
        that.showToast();
      },
    })
  },

  showToast: function (postCollected, postsCollected) {
    wx.setStorageSync('posts_collected', postsCollected)
     this.setData({
       collected:postsCollected
     })
    wx.showToast({
      title: postCollected ? "收藏成功" : "取消成功",
      // title: '收藏',
      icon: 'success',
      duration: 1000,
      // 是否显示透明蒙层，防止触摸穿透，默认：false
      mask: true, 
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  }

})